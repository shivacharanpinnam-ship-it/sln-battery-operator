import { u as products_exports } from "../_ssr/router-DVz2Q-_d.mjs";
export { products_exports as r };
