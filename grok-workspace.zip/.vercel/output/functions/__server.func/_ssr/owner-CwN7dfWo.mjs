import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { f as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as createProduct, d as removeProduct, n as Route } from "./router-DVz2Q-_d.mjs";
import { i as Textarea, n as Input, o as formatInr, r as Label, t as Button } from "./textarea-J7rVP_TX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/owner-CwN7dfWo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PIN_KEY = "sln-owner-pin";
async function shrinkPhoto(file) {
	const dataUrl = await new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not read photo"));
		reader.onload = () => {
			const image = new Image();
			image.onerror = () => reject(/* @__PURE__ */ new Error("Could not load photo"));
			image.onload = () => {
				const scale = Math.min(1, 720 / Math.max(image.width, image.height));
				const canvas = document.createElement("canvas");
				canvas.width = Math.max(1, Math.round(image.width * scale));
				canvas.height = Math.max(1, Math.round(image.height * scale));
				const ctx = canvas.getContext("2d");
				if (!ctx) {
					reject(/* @__PURE__ */ new Error("Could not process photo"));
					return;
				}
				ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
				resolve(canvas.toDataURL("image/jpeg", .7));
			};
			image.src = String(reader.result);
		};
		reader.readAsDataURL(file);
	});
	if (dataUrl.length > 24e4) throw new Error("Photo is too large. Try a smaller picture.");
	return dataUrl;
}
function OwnerUnlock({ onUnlock }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		const pin = String(new FormData(event.currentTarget).get("pin") ?? "");
		setBusy(true);
		try {
			const { verifyOwnerPin } = await import("../_libs/_.mjs").then((n) => n.r);
			await verifyOwnerPin({ data: { pin } });
			sessionStorage.setItem(PIN_KEY, pin);
			onUnlock(pin);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not unlock the panel");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "mx-auto max-w-md rounded-xl border-2 border-dashed border-primary/50 bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Owner panel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Enter the shop PIN to add cars and prices. Hint: last 5 digits of the main phone number."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
				className: "mt-5 block",
				children: ["PIN", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					name: "pin",
					type: "password",
					inputMode: "numeric",
					required: true,
					minLength: 4,
					autoComplete: "current-password"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "mt-5",
				disabled: busy,
				children: busy ? "Checking…" : "Unlock"
			})
		]
	});
}
function OwnerCatalog({ pin, products }) {
	const router = useRouter();
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onAdd(event) {
		event.preventDefault();
		const form = event.currentTarget;
		const data = new FormData(form);
		const file = data.get("photo");
		setBusy(true);
		try {
			let photo = null;
			if (file instanceof File && file.size > 0) photo = await shrinkPhoto(file);
			await createProduct({ data: {
				pin,
				name: String(data.get("name") ?? ""),
				price_inr: Number(data.get("price")),
				age_group: String(data.get("age") ?? ""),
				description: String(data.get("description") ?? ""),
				color: String(data.get("color") || "#D61F36"),
				photo
			} });
			form.reset();
			toast.success("Car saved to the shop");
			await router.invalidate();
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not save this car");
		} finally {
			setBusy(false);
		}
	}
	async function onRemove(id) {
		try {
			await removeProduct({ data: {
				pin,
				id
			} });
			toast.success("Car removed");
			await router.invalidate();
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not remove this car");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[minmax(0,22rem)_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: onAdd,
			className: "h-fit rounded-xl border-2 border-dashed border-primary/50 bg-card p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: "Add a car"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Name, price, and an optional photo. Saved cars show up in the shop for every customer."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Car name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "name",
							required: true,
							maxLength: 80
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Price (₹)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								name: "price",
								type: "number",
								min: 1,
								required: true
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Age group", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								name: "age",
								placeholder: "3–6 yrs",
								maxLength: 40
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Short description", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							name: "description",
							rows: 3,
							maxLength: 240
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Accent color", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "color",
							type: "color",
							defaultValue: "#D61F36"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Photo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "photo",
							type: "file",
							accept: "image/*"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: busy,
							children: busy ? "Saving…" : "Save product"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-semibold",
			children: "Your products"
		}), products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-muted",
			children: "No products yet."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 divide-y-2 divide-dashed divide-border",
			children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 py-3 first:pt-0",
				children: [
					product.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: product.photo,
						alt: "",
						className: "size-14 rounded-sm object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "size-14 rounded-sm",
						style: { background: product.color },
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-semibold",
							children: product.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted tabular-nums",
							children: [formatInr(product.price_inr), product.age_group ? ` · ${product.age_group}` : ""]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => onRemove(product.id),
						children: "Remove"
					})
				]
			}, product.id))
		})] })]
	});
}
function readStoredPin() {
	try {
		return sessionStorage.getItem(PIN_KEY);
	} catch {
		return null;
	}
}
function OwnerPage() {
	const products = Route.useLoaderData();
	const [pin, setPin] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setPin(readStoredPin());
		setReady(true);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-dvh max-w-6xl px-5 py-10 sm:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/",
			className: "mb-6 inline-flex items-center gap-2 font-display text-sm font-semibold text-muted hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Back to shop"]
		}), !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Loading owner panel…"
		}) : pin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display mb-6 text-4xl font-semibold",
			children: "Owner panel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnerCatalog, {
			pin,
			products
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnerUnlock, { onUnlock: setPin })]
	});
}
//#endregion
export { OwnerPage as component };
