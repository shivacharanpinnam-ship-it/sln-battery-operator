import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as string, n as number, r as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products-BpEYiZBA.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var pinSchema = string().trim().min(4).max(32);
var productInput = object({
	pin: pinSchema,
	name: string().trim().min(1).max(80),
	price_inr: number().int().min(1).max(1e7),
	age_group: string().trim().max(40),
	description: string().trim().max(240),
	color: string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
	photo: string().max(25e4).nullable()
});
async function assertOwnerPin(pin) {
	const { createHash, timingSafeEqual } = await import("node:crypto");
	const { getSql } = await import("./db-zxZH4Yg6.mjs");
	const hash = createHash("sha256").update(`sln-toys:${pin.trim()}`).digest("hex");
	const expected = (await (await getSql())`
    select pin_hash from shop_settings where id = 1
  `)[0]?.pin_hash ?? "";
	const left = Buffer.from(hash);
	const right = Buffer.from(expected);
	if (left.length !== right.length || !timingSafeEqual(left, right)) throw new Error("Wrong PIN. Use the last 5 digits of the shop phone.");
}
var listProducts_createServerFn_handler = createServerRpc({
	id: "e34c3bc8ce7cecd640542cf4ee5b438bf6de146316880ab88e6bfdd5ed480a2a",
	name: "listProducts",
	filename: "src/lib/products.ts"
}, (opts) => listProducts.__executeServer(opts));
var listProducts = createServerFn({ method: "GET" }).handler(listProducts_createServerFn_handler, async () => {
	const { getSql } = await import("./db-zxZH4Yg6.mjs");
	return (await getSql())`
      select
        id,
        name,
        price_inr,
        age_group,
        description,
        color,
        photo,
        created_at::text as created_at
      from products
      order by created_at desc
    `;
});
var verifyOwnerPin_createServerFn_handler = createServerRpc({
	id: "77db335c217c225691da2a44ed11dbb4a0b28f01c3c2c8ba8f7eb717cc8b1be8",
	name: "verifyOwnerPin",
	filename: "src/lib/products.ts"
}, (opts) => verifyOwnerPin.__executeServer(opts));
var verifyOwnerPin = createServerFn({ method: "POST" }).validator(object({ pin: pinSchema })).handler(verifyOwnerPin_createServerFn_handler, async ({ data }) => {
	await assertOwnerPin(data.pin);
	return { ok: true };
});
var createProduct_createServerFn_handler = createServerRpc({
	id: "4423d602a039b6f6555b9da596604b79d01ade4e071081365dd7ffe18a003fd7",
	name: "createProduct",
	filename: "src/lib/products.ts"
}, (opts) => createProduct.__executeServer(opts));
var createProduct = createServerFn({ method: "POST" }).validator(productInput).handler(createProduct_createServerFn_handler, async ({ data }) => {
	await assertOwnerPin(data.pin);
	const { getSql } = await import("./db-zxZH4Yg6.mjs");
	const sql = await getSql();
	const id = `p-${Date.now().toString(36)}`;
	await sql`
      insert into products (id, name, price_inr, age_group, description, color, photo)
      values (
        ${id},
        ${data.name},
        ${data.price_inr},
        ${data.age_group},
        ${data.description},
        ${data.color ?? "#D61F36"},
        ${data.photo}
      )
    `;
	return { id };
});
var removeProduct_createServerFn_handler = createServerRpc({
	id: "7d654a57ced2dc3a97e2ede4027dd4d2d5f3abe9c9ac1e140d8b4edf3a216bce",
	name: "removeProduct",
	filename: "src/lib/products.ts"
}, (opts) => removeProduct.__executeServer(opts));
var removeProduct = createServerFn({ method: "POST" }).validator(object({
	pin: pinSchema,
	id: string().min(1).max(80)
})).handler(removeProduct_createServerFn_handler, async ({ data }) => {
	await assertOwnerPin(data.pin);
	const { getSql } = await import("./db-zxZH4Yg6.mjs");
	await (await getSql())`delete from products where id = ${data.id}`;
	return { ok: true };
});
//#endregion
export { createProduct_createServerFn_handler, listProducts_createServerFn_handler, removeProduct_createServerFn_handler, verifyOwnerPin_createServerFn_handler };
