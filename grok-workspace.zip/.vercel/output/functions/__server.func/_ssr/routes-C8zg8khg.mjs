import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Plus, c as MessageCircle, d as ExternalLink, i as ShoppingBag, l as MapPin, o as Phone, r as Trash2, s as Minus, t as X, u as Mail } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useCart, i as cartCount, o as useShopUi, r as Route$1 } from "./router-DVz2Q-_d.mjs";
import { a as cn, i as Textarea, n as Input, o as formatInr, r as Label, t as Button } from "./textarea-J7rVP_TX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C8zg8khg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-foreground/55 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 grid w-[min(34rem,calc(100vw-1.5rem))] max-h-[min(90vh,40rem)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-xl border-2 border-foreground/12 bg-background p-5 text-foreground shadow-lg", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			className: "absolute top-3 right-3 inline-flex size-10 items-center justify-center rounded-full text-foreground hover:bg-foreground/6",
			"aria-label": "Close",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pr-10", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-2xl font-semibold leading-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("mt-1 text-muted", className),
		...props
	});
}
function CartDialog({ products }) {
	const open = useShopUi((s) => s.cartOpen);
	const closeCart = useShopUi((s) => s.closeCart);
	const openCheckout = useShopUi((s) => s.openCheckout);
	const items = useCart((s) => s.items);
	const inc = useCart((s) => s.inc);
	const dec = useCart((s) => s.dec);
	const remove = useCart((s) => s.remove);
	const lines = items.map((item) => {
		const product = products.find((p) => p.id === item.id);
		return product ? {
			product,
			qty: item.qty
		} : null;
	}).filter((line) => line !== null);
	const total = lines.reduce((sum, line) => sum + line.product.price_inr * line.qty, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => !next && closeCart(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Your cart" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Review the cars, then send your delivery details to the shop on WhatsApp." })] }), lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Your cart is empty."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-4",
				onClick: closeCart,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#shop",
					children: "Shop now"
				})
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-1",
			children: [lines.map(({ product, qty }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 border-b-2 border-dashed border-border py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-semibold",
						children: product.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted tabular-nums",
						children: formatInr(product.price_inr)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							className: "size-9",
							onClick: () => dec(product.id),
							"aria-label": `Fewer ${product.name}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-6 text-center font-semibold tabular-nums",
							children: qty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							className: "size-9",
							onClick: () => inc(product.id),
							"aria-label": `More ${product.name}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "size-9",
							onClick: () => remove(product.id),
							"aria-label": `Remove ${product.name}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})
					]
				})]
			}, product.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-xl font-semibold tabular-nums",
					children: ["Total ", formatInr(total)]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: openCheckout,
					children: "Checkout"
				})]
			})]
		})] })
	});
}
var SHOP = {
	name: "Sln Electric Toys",
	phone: "+91 99896 48742",
	phone2: "+91 76610 98439",
	wa: "919989648742",
	email: "pinnamraghavendra589@gmail.com",
	addresses: ["11th Floor, 4-97, near Gem Motors, beside More Super Market, Kondapur, Raghavendra Colony", "Sai Chandra Colony, Plot No 85, Narsingi – Puppalaguda Main Rd, opposite GREENSPACE PRIME"]
};
function buildOrderMessage(orderId, lines, total, details) {
	const items = lines.map((line) => `${line.name} × ${line.qty} = ₹${line.price * line.qty}`).join("\n");
	return [
		`New order ${orderId} from ${SHOP.name}`,
		items,
		`Total: ₹${total}`,
		"",
		`Name: ${details.name}`,
		`Phone: ${details.phone}`,
		details.email ? `Email: ${details.email}` : "",
		`Delivery address: ${details.address}, ${details.city}, ${details.state} - ${details.pincode}`
	].filter(Boolean).join("\n");
}
function whatsappOrderUrl(message) {
	return `https://wa.me/${SHOP.wa}?text=${encodeURIComponent(message)}`;
}
function telHref(phone) {
	return `tel:${phone.replace(/\s/g, "")}`;
}
function mapsHref(address) {
	return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
}
function CheckoutDialog({ products }) {
	const open = useShopUi((s) => s.checkoutOpen);
	const closeCheckout = useShopUi((s) => s.closeCheckout);
	const items = useCart((s) => s.items);
	const clear = useCart((s) => s.clear);
	const [waUrl, setWaUrl] = (0, import_react.useState)(null);
	const [orderId, setOrderId] = (0, import_react.useState)("");
	const [total, setTotal] = (0, import_react.useState)(0);
	const lines = items.map((item) => {
		const product = products.find((p) => p.id === item.id);
		return product ? {
			name: product.name,
			qty: item.qty,
			price: product.price_inr
		} : null;
	}).filter((line) => line !== null);
	const liveTotal = lines.reduce((sum, line) => sum + line.price * line.qty, 0);
	function onOpenChange(next) {
		if (!next) {
			closeCheckout();
			setWaUrl(null);
		}
	}
	function onSubmit(event) {
		event.preventDefault();
		if (lines.length === 0) return;
		const form = new FormData(event.currentTarget);
		const details = {
			name: String(form.get("name") ?? "").trim(),
			phone: String(form.get("phone") ?? "").trim(),
			email: String(form.get("email") ?? "").trim(),
			address: String(form.get("address") ?? "").trim(),
			city: String(form.get("city") ?? "").trim(),
			pincode: String(form.get("pincode") ?? "").trim(),
			state: String(form.get("state") ?? "").trim()
		};
		const id = `SLN${Date.now().toString().slice(-6)}`;
		const url = whatsappOrderUrl(buildOrderMessage(id, lines, liveTotal, details));
		setOrderId(id);
		setTotal(liveTotal);
		setWaUrl(url);
		clear();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: waUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Send this order on WhatsApp" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				"Order ",
				orderId,
				" · ",
				formatInr(total),
				". Your name, phone, and delivery address are packed into a message for the shop owner."
			] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-md bg-sun/25 px-3 py-2 text-sm",
				children: "WhatsApp should open with the order ready to send. If it did not, tap the button below."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-5 w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: waUrl,
					target: "_blank",
					rel: "noopener noreferrer",
					children: ["Open WhatsApp", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
				})
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Delivery details" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
			"We send this to the owner on WhatsApp. Total ",
			formatInr(liveTotal),
			"."
		] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 grid gap-3",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Your name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					name: "name",
					required: true,
					autoComplete: "name"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Phone", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "phone",
						type: "tel",
						required: true,
						autoComplete: "tel"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "email",
						type: "email",
						autoComplete: "email",
						placeholder: "Optional"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Delivery address", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					name: "address",
					required: true,
					rows: 2,
					autoComplete: "street-address"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["City", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "city",
						required: true,
						autoComplete: "address-level2"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Pincode", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "pincode",
						inputMode: "numeric",
						required: true,
						pattern: "[0-9]{6}",
						autoComplete: "postal-code"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["State", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					name: "state",
					required: true,
					defaultValue: "Telangana",
					autoComplete: "address-level1"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "mt-2 w-full",
					children: "Send order on WhatsApp"
				})
			]
		})] }) })
	});
}
var cards = [
	{
		href: telHref(SHOP.phone),
		icon: Phone,
		label: "Call us",
		value: SHOP.phone
	},
	{
		href: telHref(SHOP.phone2),
		icon: Phone,
		label: "Second number",
		value: SHOP.phone2
	},
	{
		href: `https://wa.me/${SHOP.wa}`,
		icon: MessageCircle,
		label: "WhatsApp",
		value: "Chat with the shop",
		external: true
	},
	{
		href: `mailto:${SHOP.email}`,
		icon: Mail,
		label: "Email",
		value: SHOP.email
	}
];
function ContactSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "contact",
		className: "mx-auto max-w-6xl px-5 py-16 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-[clamp(1.8rem,4vw,2.6rem)] font-semibold",
				children: "Talk to us"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-muted",
				children: "Questions about a car or your order? Call, message, or visit the shop."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2",
				children: [cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: card.href,
					target: card.external ? "_blank" : void 0,
					rel: card.external ? "noopener noreferrer" : void 0,
					className: "rounded-lg border-2 border-foreground/12 bg-card p-5 no-underline transition-colors hover:border-foreground/30",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 font-display text-lg font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(card.icon, { className: "size-4" }), card.label]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 break-all text-muted",
						children: card.value
					})]
				}, card.label)), SHOP.addresses.map((address, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: mapsHref(address),
					target: "_blank",
					rel: "noopener noreferrer",
					className: "rounded-lg border-2 border-foreground/12 bg-card p-5 no-underline transition-colors hover:border-foreground/30",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 font-display text-lg font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }),
								"Location ",
								index + 1
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: address
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-semibold text-ring",
							children: "Open in Maps"
						})
					]
				}, address))]
			})
		]
	});
}
function PopTitle({ text }) {
	const colors = [
		"var(--color-primary)",
		"var(--color-ring)",
		"var(--color-hill)",
		"var(--color-foreground)"
	];
	let i = 0;
	const words = text.split(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "hero-title font-display max-w-[12ch] text-[clamp(2.6rem,11vw,5.4rem)] leading-[0.95] font-bold tracking-tight text-foreground",
		"aria-label": text,
		children: words.map((word, wi) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mr-[0.28em] inline-block whitespace-nowrap",
			children: [...word].map((ch, ci) => {
				const delay = i++;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ch",
					style: {
						"--i": delay,
						color: colors[delay % colors.length]
					},
					"aria-hidden": "true",
					children: ch
				}, `${ch}-${ci}`);
			})
		}, `${word}-${wi}`))
	});
}
function RideOnCar({ body, shirt, hair, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className,
		viewBox: "0 0 220 130",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: "kid-bob",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M104 62 L96 44",
						stroke: shirt,
						strokeWidth: "9",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "92",
						y: "40",
						width: "38",
						height: "40",
						rx: "12",
						fill: shirt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M124 52 L150 66",
						stroke: shirt,
						strokeWidth: "9",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "111",
						cy: "26",
						r: "19",
						fill: "#E8B894"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M92 26 A19 19 0 0 1 130 24 Q111 16 92 26Z",
						fill: hair
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "104",
						cy: "27",
						r: "2.6",
						fill: "#1A2744"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "118",
						cy: "27",
						r: "2.6",
						fill: "#1A2744"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M103 35 Q111 43 119 35",
						stroke: "#1A2744",
						strokeWidth: "2.6",
						fill: "none",
						strokeLinecap: "round"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "10",
				y: "68",
				width: "200",
				height: "38",
				rx: "16",
				fill: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M128 68 L146 52 H156 L168 68Z",
				fill: "#BDE6FA"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M60 78 L52 92 H60 L56 102 L70 86 H62 L66 78Z",
				fill: "#F2C14E"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "196",
				y: "78",
				width: "12",
				height: "9",
				rx: "4",
				fill: "#F2C14E"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: "wheel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "56",
					cy: "108",
					r: "17",
					fill: "#1A2744"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "56",
					cy: "108",
					r: "7",
					fill: "#F2C14E"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: "wheel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "164",
					cy: "108",
					r: "17",
					fill: "#1A2744"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "164",
					cy: "108",
					r: "7",
					fill: "#F2C14E"
				})]
			})
		]
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "hero-scene relative overflow-hidden px-5 pt-12 pb-64 min-h-[34rem] text-foreground sm:px-8 sm:pb-72",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hero-sun absolute top-7 right-[7%] z-0 size-24 rounded-full bg-sun sm:size-28",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hero-cloud absolute top-10 z-0 h-8 w-28 rounded-full bg-card",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hero-cloud absolute top-28 z-0 h-8 w-28 scale-75 rounded-full bg-card",
				style: { animationDelay: "-18s" },
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto max-w-6xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopTitle, { text: "Zoom into the fun!" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-[32ch] text-lg font-medium text-foreground/80",
						children: "Battery cars for little drivers. Pick one, add it to your cart, and we deliver it to your door."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						className: "mt-6 bg-sun text-foreground shadow-press hover:brightness-105",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#shop",
							children: "Shop now"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hero-hill absolute right-[-10%] bottom-12 left-[-10%] z-0 h-36 rounded-t-[50%] bg-hill",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hero-road absolute right-0 bottom-0 left-0 z-0 h-[4.75rem] bg-road",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RideOnCar, {
				className: "hero-car absolute bottom-9 left-[-230px] z-10 w-52 sm:w-[210px]",
				body: "#D61F36",
				shirt: "#2563EB",
				hair: "#4B2E1E"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RideOnCar, {
				className: "hero-car hero-car-two absolute bottom-9 left-[-230px] z-10 w-44 sm:w-[180px]",
				body: "#2FA4D7",
				shirt: "#DB2777",
				hair: "#8A5A2B"
			})
		]
	});
}
function Badge({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full bg-foreground px-2.5 py-0.5 text-xs font-semibold text-primary-foreground", className),
		...props
	});
}
function ProductCard({ product }) {
	const add = useCart((s) => s.add);
	const openCart = useShopUi((s) => s.openCart);
	function onAdd() {
		add(product.id);
		toast.success(`${product.name} added to cart`, { action: {
			label: "View cart",
			onClick: openCart
		} });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col overflow-hidden rounded-xl border-[2.5px] bg-card",
		style: { borderColor: product.color },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pic-frame relative overflow-hidden bg-sky/40",
			children: [product.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: product.photo,
				alt: product.name,
				className: "size-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-full items-center justify-center",
				style: { background: product.color },
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-5xl text-primary-foreground",
					children: product.name.slice(0, 1)
				})
			}), product.age_group ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				className: "absolute top-3 left-3",
				children: product.age_group
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-2 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl font-semibold leading-tight",
					children: product.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "flex-1 text-sm text-muted",
					children: product.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-bold text-primary tabular-nums",
						children: formatInr(product.price_inr)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: onAdd,
						children: "Add to cart"
					})]
				})
			]
		})]
	});
}
function ProductGrid({ products }) {
	if (products.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-lg border-2 border-dashed border-border bg-card px-5 py-10 text-center text-muted",
		children: "No cars in the shop yet. The owner can add them from the owner panel."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3",
		children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t-8 border-primary px-5 py-8 text-center text-sm text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			"© ",
			(/* @__PURE__ */ new Date()).getFullYear(),
			" Sln Electric Toys"
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/owner",
			className: "mt-2 inline-block font-semibold text-foreground/70 hover:text-primary",
			children: "Owner panel"
		})]
	});
}
function SiteHeader() {
	const items = useCart((s) => s.items);
	const openCart = useShopUi((s) => s.openCart);
	const count = cartCount(items);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b-2 border-border bg-background/95 pt-[env(safe-area-inset-top)] backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "font-display mr-auto text-lg font-bold leading-none sm:text-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary",
							children: "Sln"
						}),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-ring",
							children: "Electric"
						}),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-hill",
							children: "Toys"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-5 font-display text-sm font-semibold sm:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#shop",
						className: "hover:text-primary",
						children: "Shop"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#contact",
						className: "hover:text-primary",
						children: "Contact"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: openCart,
					"aria-label": `Cart, ${count} items`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4" }),
						"Cart",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								"(",
								count,
								")"
							]
						})
					]
				})
			]
		})
	});
}
function Home() {
	const products = Route$1.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "shop",
				className: "mx-auto max-w-6xl px-5 py-16 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-[clamp(1.8rem,4vw,2.6rem)] font-semibold",
						children: "Our battery cars"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 mb-8 text-muted",
						children: "Tap Add to cart on the cars you like. Checkout sends your delivery address to the shop on WhatsApp."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartDialog, { products }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckoutDialog, { products })
		]
	});
}
//#endregion
export { Home as component };
