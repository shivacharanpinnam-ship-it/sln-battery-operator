import "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatInr(amount) {
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(amount);
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-display font-semibold transition-[transform,filter,background-color,box-shadow] duration-150 ease-out focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:pointer-events-none disabled:opacity-50 active:translate-y-px", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-[var(--shadow-press)] hover:brightness-105 active:shadow-none",
			secondary: "bg-card text-foreground border-2 border-foreground/12 hover:border-foreground/28",
			outline: "bg-transparent text-foreground border-2 border-foreground/20 hover:bg-foreground/5",
			ghost: "bg-transparent text-foreground hover:bg-foreground/6"
		},
		size: {
			default: "h-11 rounded-full px-5 text-base",
			sm: "h-9 rounded-full px-4 text-sm",
			lg: "h-12 rounded-full px-6 text-lg",
			icon: "size-11 rounded-full"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("h-11 w-full rounded-md border-2 border-border bg-card px-3.5 text-base text-foreground", "placeholder:text-muted/80 focus-visible:border-ring", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		"data-slot": "label",
		className: cn("text-sm font-semibold text-foreground [&_input]:mt-1.5 [&_textarea]:mt-1.5", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		"data-slot": "textarea",
		className: cn("min-h-24 w-full rounded-md border-2 border-border bg-card px-3.5 py-2.5 text-base text-foreground", "placeholder:text-muted/80 focus-visible:border-ring", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
//#endregion
export { cn as a, Textarea as i, Input as n, formatInr as o, Label as r, Button as t };
