//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DD1NIogz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/owner"],
		preloads: ["/assets/index-CLgJE_6q.js", "/assets/products-C5b6wi68.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CLgJE_6q.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B_mAPQXy.js", "/assets/textarea-DWi_McHb.js"]
	},
	"/owner": {
		filePath: "/workspace/src/routes/owner.tsx",
		children: void 0,
		preloads: ["/assets/owner-CxQh2XK2.js", "/assets/textarea-DWi_McHb.js"]
	}
} });
//#endregion
export { tsrStartManifest };
