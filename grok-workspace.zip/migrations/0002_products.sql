-- Shared product catalog for Sln Electric Toys (unowned rows; auth is off).
create table if not exists products (
  id          text primary key,
  name        text not null,
  price_inr   integer not null check (price_inr > 0),
  age_group   text not null default '',
  description text not null default '',
  color       text not null default '#D61F36',
  photo       text,
  created_at  timestamptz not null default now()
);

create table if not exists shop_settings (
  id       integer primary key check (id = 1),
  pin_hash text not null
);

-- Owner PIN is the last 5 digits of the shop phone (48742), hashed at rest.
insert into shop_settings (id, pin_hash)
values (1, 'f4c3f39fd6c20caf132672c4fab151776fb19f8e66ab8a3dc3532f0dcda9bf14')
on conflict (id) do nothing;

insert into products (id, name, price_inr, age_group, description, color, photo)
values
  (
    'p-red-racer',
    'Red Racer',
    6999,
    '3–6 yrs',
    'Low sports ride-on with a parent remote and working headlights.',
    '#D61F36',
    '/products/red-racer.jpg'
  ),
  (
    'p-mini-jeep',
    'Mini Jeep',
    8499,
    '4–8 yrs',
    'Chunky off-road jeep with a roll bar and extra battery range.',
    '#4B6B3A',
    '/products/mini-jeep.jpg'
  ),
  (
    'p-police-patrol',
    'Police Patrol',
    7499,
    '3–7 yrs',
    'Patrol car with a roof light bar, siren sounds, and a spacious seat.',
    '#1A2744',
    '/products/police-patrol.jpg'
  ),
  (
    'p-pink-coupe',
    'Blush Coupe',
    7999,
    '2–6 yrs',
    'Rounded city coupe with a gentle start and a high backrest.',
    '#E38AA8',
    '/products/pink-coupe.jpg'
  ),
  (
    'p-off-road',
    'Trail Crawler',
    9499,
    '5–8 yrs',
    'High-clearance crawler with knobby tyres for garden paths.',
    '#E25822',
    '/products/off-road.jpg'
  ),
  (
    'p-sky-convertible',
    'Sky Convertible',
    8299,
    '3–6 yrs',
    'Open-top convertible with a USB charger port and smooth steering.',
    '#2FA4D7',
    '/products/sky-convertible.jpg'
  )
on conflict (id) do nothing;
