import { Minus, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useCart, useShopUi } from "@/lib/cart";
import type { Product } from "@/lib/products";
import { formatInr } from "@/lib/utils";

export function CartDialog({ products }: { products: Product[] }) {
  const open = useShopUi((s) => s.cartOpen);
  const closeCart = useShopUi((s) => s.closeCart);
  const openCheckout = useShopUi((s) => s.openCheckout);
  const items = useCart((s) => s.items);
  const inc = useCart((s) => s.inc);
  const dec = useCart((s) => s.dec);
  const remove = useCart((s) => s.remove);

  const lines = items
    .map((item) => {
      const product = products.find((p) => p.id === item.id);
      return product ? { product, qty: item.qty } : null;
    })
    .filter((line) => line !== null);
  const total = lines.reduce(
    (sum, line) => sum + line.product.price_inr * line.qty,
    0,
  );

  return (
    <Dialog open={open} onOpenChange={(next) => !next && closeCart()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Your cart</DialogTitle>
          <DialogDescription>
            Review the cars, then send your delivery details to the shop on
            WhatsApp.
          </DialogDescription>
        </DialogHeader>

        {lines.length === 0 ? (
          <div className="py-6">
            <p className="text-muted">Your cart is empty.</p>
            <Button asChild className="mt-4" onClick={closeCart}>
              <a href="#shop">Shop now</a>
            </Button>
          </div>
        ) : (
          <div className="mt-4 space-y-1">
            {lines.map(({ product, qty }) => (
              <div
                key={product.id}
                className="flex items-center gap-3 border-b-2 border-dashed border-border py-3"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{product.name}</p>
                  <p className="text-sm text-muted tabular-nums">
                    {formatInr(product.price_inr)}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <Button
                    variant="outline"
                    size="icon"
                    className="size-9"
                    onClick={() => dec(product.id)}
                    aria-label={`Fewer ${product.name}`}
                  >
                    <Minus className="size-4" />
                  </Button>
                  <span className="w-6 text-center font-semibold tabular-nums">
                    {qty}
                  </span>
                  <Button
                    variant="outline"
                    size="icon"
                    className="size-9"
                    onClick={() => inc(product.id)}
                    aria-label={`More ${product.name}`}
                  >
                    <Plus className="size-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-9"
                    onClick={() => remove(product.id)}
                    aria-label={`Remove ${product.name}`}
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              </div>
            ))}
            <div className="flex items-center justify-between gap-3 pt-4">
              <p className="font-display text-xl font-semibold tabular-nums">
                Total {formatInr(total)}
              </p>
              <Button onClick={openCheckout}>Checkout</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
