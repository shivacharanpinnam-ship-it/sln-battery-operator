import { useState, type FormEvent } from "react";
import { ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useCart, useShopUi } from "@/lib/cart";
import type { Product } from "@/lib/products";
import {
  buildOrderMessage,
  type CheckoutDetails,
  whatsappOrderUrl,
} from "@/lib/shop";
import { formatInr } from "@/lib/utils";

export function CheckoutDialog({ products }: { products: Product[] }) {
  const open = useShopUi((s) => s.checkoutOpen);
  const closeCheckout = useShopUi((s) => s.closeCheckout);
  const items = useCart((s) => s.items);
  const clear = useCart((s) => s.clear);
  const [waUrl, setWaUrl] = useState<string | null>(null);
  const [orderId, setOrderId] = useState("");
  const [total, setTotal] = useState(0);

  const lines = items
    .map((item) => {
      const product = products.find((p) => p.id === item.id);
      return product
        ? { name: product.name, qty: item.qty, price: product.price_inr }
        : null;
    })
    .filter((line) => line !== null);
  const liveTotal = lines.reduce(
    (sum, line) => sum + line.price * line.qty,
    0,
  );

  function onOpenChange(next: boolean) {
    if (!next) {
      closeCheckout();
      setWaUrl(null);
    }
  }

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (lines.length === 0) return;
    const form = new FormData(event.currentTarget);
    const details: CheckoutDetails = {
      name: String(form.get("name") ?? "").trim(),
      phone: String(form.get("phone") ?? "").trim(),
      email: String(form.get("email") ?? "").trim(),
      address: String(form.get("address") ?? "").trim(),
      city: String(form.get("city") ?? "").trim(),
      pincode: String(form.get("pincode") ?? "").trim(),
      state: String(form.get("state") ?? "").trim(),
    };
    const id = `SLN${Date.now().toString().slice(-6)}`;
    const message = buildOrderMessage(id, lines, liveTotal, details);
    const url = whatsappOrderUrl(message);
    setOrderId(id);
    setTotal(liveTotal);
    setWaUrl(url);
    clear();
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        {waUrl ? (
          <>
            <DialogHeader>
              <DialogTitle>Send this order on WhatsApp</DialogTitle>
              <DialogDescription>
                Order {orderId} · {formatInr(total)}. Your name, phone, and
                delivery address are packed into a message for the shop owner.
              </DialogDescription>
            </DialogHeader>
            <p className="mt-3 rounded-md bg-sun/25 px-3 py-2 text-sm">
              WhatsApp should open with the order ready to send. If it did not,
              tap the button below.
            </p>
            <Button asChild className="mt-5 w-full">
              <a href={waUrl} target="_blank" rel="noopener noreferrer">
                Open WhatsApp
                <ExternalLink className="size-4" />
              </a>
            </Button>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Delivery details</DialogTitle>
              <DialogDescription>
                We send this to the owner on WhatsApp. Total {formatInr(liveTotal)}.
              </DialogDescription>
            </DialogHeader>
            <form className="mt-4 grid gap-3" onSubmit={onSubmit}>
              <Label>
                Your name
                <Input name="name" required autoComplete="name" />
              </Label>
              <div className="grid gap-3 sm:grid-cols-2">
                <Label>
                  Phone
                  <Input
                    name="phone"
                    type="tel"
                    required
                    autoComplete="tel"
                  />
                </Label>
                <Label>
                  Email
                  <Input
                    name="email"
                    type="email"
                    autoComplete="email"
                    placeholder="Optional"
                  />
                </Label>
              </div>
              <Label>
                Delivery address
                <Textarea
                  name="address"
                  required
                  rows={2}
                  autoComplete="street-address"
                />
              </Label>
              <div className="grid gap-3 sm:grid-cols-2">
                <Label>
                  City
                  <Input name="city" required autoComplete="address-level2" />
                </Label>
                <Label>
                  Pincode
                  <Input
                    name="pincode"
                    inputMode="numeric"
                    required
                    pattern="[0-9]{6}"
                    autoComplete="postal-code"
                  />
                </Label>
              </div>
              <Label>
                State
                <Input
                  name="state"
                  required
                  defaultValue="Telangana"
                  autoComplete="address-level1"
                />
              </Label>
              <Button type="submit" className="mt-2 w-full">
                Send order on WhatsApp
              </Button>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
