import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { mapsHref, SHOP, telHref } from "@/lib/shop";

const cards = [
  {
    href: telHref(SHOP.phone),
    icon: Phone,
    label: "Call us",
    value: SHOP.phone,
  },
  {
    href: telHref(SHOP.phone2),
    icon: Phone,
    label: "Second number",
    value: SHOP.phone2,
  },
  {
    href: `https://wa.me/${SHOP.wa}`,
    icon: MessageCircle,
    label: "WhatsApp",
    value: "Chat with the shop",
    external: true,
  },
  {
    href: `mailto:${SHOP.email}`,
    icon: Mail,
    label: "Email",
    value: SHOP.email,
  },
];

export function ContactSection() {
  return (
    <section id="contact" className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
      <h2 className="font-display text-[clamp(1.8rem,4vw,2.6rem)] font-semibold">
        Talk to us
      </h2>
      <p className="mt-2 max-w-xl text-muted">
        Questions about a car or your order? Call, message, or visit the shop.
      </p>
      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {cards.map((card) => (
          <a
            key={card.label}
            href={card.href}
            target={card.external ? "_blank" : undefined}
            rel={card.external ? "noopener noreferrer" : undefined}
            className="rounded-lg border-2 border-foreground/12 bg-card p-5 no-underline transition-colors hover:border-foreground/30"
          >
            <p className="flex items-center gap-2 font-display text-lg font-semibold">
              <card.icon className="size-4" />
              {card.label}
            </p>
            <p className="mt-1 break-all text-muted">{card.value}</p>
          </a>
        ))}
        {SHOP.addresses.map((address, index) => (
          <a
            key={address}
            href={mapsHref(address)}
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-lg border-2 border-foreground/12 bg-card p-5 no-underline transition-colors hover:border-foreground/30"
          >
            <p className="flex items-center gap-2 font-display text-lg font-semibold">
              <MapPin className="size-4" />
              Location {index + 1}
            </p>
            <p className="mt-1 text-muted">{address}</p>
            <p className="mt-2 text-sm font-semibold text-ring">Open in Maps</p>
          </a>
        ))}
      </div>
    </section>
  );
}
