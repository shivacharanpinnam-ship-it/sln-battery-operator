import type { CSSProperties } from "react";
import { Button } from "@/components/ui/button";

function PopTitle({ text }: { text: string }) {
  const colors = [
    "var(--color-primary)",
    "var(--color-ring)",
    "var(--color-hill)",
    "var(--color-foreground)",
  ];
  let i = 0;
  const words = text.split(" ");
  return (
    <h1
      className="hero-title font-display max-w-[12ch] text-[clamp(2.6rem,11vw,5.4rem)] leading-[0.95] font-bold tracking-tight text-foreground"
      aria-label={text}
    >
      {words.map((word, wi) => (
        <span key={`${word}-${wi}`} className="mr-[0.28em] inline-block whitespace-nowrap">
          {[...word].map((ch, ci) => {
            const delay = i++;
            return (
              <span
                key={`${ch}-${ci}`}
                className="ch"
                style={{
                  "--i": delay,
                  color: colors[delay % colors.length],
                } as CSSProperties}
                aria-hidden="true"
              >
                {ch}
              </span>
            );
          })}
        </span>
      ))}
    </h1>
  );
}

function RideOnCar({
  body,
  shirt,
  hair,
  className,
}: {
  body: string;
  shirt: string;
  hair: string;
  className?: string;
}) {
  return (
    <svg
      className={className}
      viewBox="0 0 220 130"
      aria-hidden="true"
      focusable="false"
    >
      <g className="kid-bob">
        <path
          d="M104 62 L96 44"
          stroke={shirt}
          strokeWidth="9"
          strokeLinecap="round"
        />
        <rect x="92" y="40" width="38" height="40" rx="12" fill={shirt} />
        <path
          d="M124 52 L150 66"
          stroke={shirt}
          strokeWidth="9"
          strokeLinecap="round"
        />
        <circle cx="111" cy="26" r="19" fill="#E8B894" />
        <path d="M92 26 A19 19 0 0 1 130 24 Q111 16 92 26Z" fill={hair} />
        <circle cx="104" cy="27" r="2.6" fill="#1A2744" />
        <circle cx="118" cy="27" r="2.6" fill="#1A2744" />
        <path
          d="M103 35 Q111 43 119 35"
          stroke="#1A2744"
          strokeWidth="2.6"
          fill="none"
          strokeLinecap="round"
        />
      </g>
      <rect x="10" y="68" width="200" height="38" rx="16" fill={body} />
      <path d="M128 68 L146 52 H156 L168 68Z" fill="#BDE6FA" />
      <path d="M60 78 L52 92 H60 L56 102 L70 86 H62 L66 78Z" fill="#F2C14E" />
      <rect x="196" y="78" width="12" height="9" rx="4" fill="#F2C14E" />
      <g className="wheel">
        <circle cx="56" cy="108" r="17" fill="#1A2744" />
        <circle cx="56" cy="108" r="7" fill="#F2C14E" />
      </g>
      <g className="wheel">
        <circle cx="164" cy="108" r="17" fill="#1A2744" />
        <circle cx="164" cy="108" r="7" fill="#F2C14E" />
      </g>
    </svg>
  );
}

export function Hero() {
  return (
    <section className="hero-scene relative overflow-hidden px-5 pt-12 pb-64 min-h-[34rem] text-foreground sm:px-8 sm:pb-72">
      <div
        className="hero-sun absolute top-7 right-[7%] z-0 size-24 rounded-full bg-sun sm:size-28"
        aria-hidden="true"
      />
      <span
        className="hero-cloud absolute top-10 z-0 h-8 w-28 rounded-full bg-card"
        aria-hidden="true"
      />
      <span
        className="hero-cloud absolute top-28 z-0 h-8 w-28 scale-75 rounded-full bg-card"
        style={{ animationDelay: "-18s" }}
        aria-hidden="true"
      />

      <div className="relative z-10 mx-auto max-w-6xl">
        <PopTitle text="Zoom into the fun!" />
        <p className="mt-5 max-w-[32ch] text-lg font-medium text-foreground/80">
          Battery cars for little drivers. Pick one, add it to your cart, and we
          deliver it to your door.
        </p>
        <Button asChild size="lg" className="mt-6 bg-sun text-foreground shadow-press hover:brightness-105">
          <a href="#shop">Shop now</a>
        </Button>
      </div>

      <div
        className="hero-hill absolute right-[-10%] bottom-12 left-[-10%] z-0 h-36 rounded-t-[50%] bg-hill"
        aria-hidden="true"
      />
      <div
        className="hero-road absolute right-0 bottom-0 left-0 z-0 h-[4.75rem] bg-road"
        aria-hidden="true"
      />
      <RideOnCar
        className="hero-car absolute bottom-9 left-[-230px] z-10 w-52 sm:w-[210px]"
        body="#D61F36"
        shirt="#2563EB"
        hair="#4B2E1E"
      />
      <RideOnCar
        className="hero-car hero-car-two absolute bottom-9 left-[-230px] z-10 w-44 sm:w-[180px]"
        body="#2FA4D7"
        shirt="#DB2777"
        hair="#8A5A2B"
      />
    </section>
  );
}
