import { useState, type FormEvent } from "react";
import { useRouter } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { createProduct, removeProduct, type Product } from "@/lib/products";
import { formatInr } from "@/lib/utils";

const PIN_KEY = "sln-owner-pin";

async function shrinkPhoto(file: File): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read photo"));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("Could not load photo"));
      image.onload = () => {
        const scale = Math.min(1, 720 / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Could not process photo"));
          return;
        }
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.7));
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
  if (dataUrl.length > 240_000) {
    throw new Error("Photo is too large. Try a smaller picture.");
  }
  return dataUrl;
}

export function OwnerUnlock({ onUnlock }: { onUnlock: (pin: string) => void }) {
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const pin = String(new FormData(event.currentTarget).get("pin") ?? "");
    setBusy(true);
    try {
      const { verifyOwnerPin } = await import("@/lib/products");
      await verifyOwnerPin({ data: { pin } });
      sessionStorage.setItem(PIN_KEY, pin);
      onUnlock(pin);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Could not unlock the panel",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <form
      onSubmit={onSubmit}
      className="mx-auto max-w-md rounded-xl border-2 border-dashed border-primary/50 bg-card p-6"
    >
      <h1 className="font-display text-3xl font-semibold">Owner panel</h1>
      <p className="mt-2 text-muted">
        Enter the shop PIN to add cars and prices. Hint: last 5 digits of the
        main phone number.
      </p>
      <Label className="mt-5 block">
        PIN
        <Input
          name="pin"
          type="password"
          inputMode="numeric"
          required
          minLength={4}
          autoComplete="current-password"
        />
      </Label>
      <Button type="submit" className="mt-5" disabled={busy}>
        {busy ? "Checking…" : "Unlock"}
      </Button>
    </form>
  );
}

export function OwnerCatalog({
  pin,
  products,
}: {
  pin: string;
  products: Product[];
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function onAdd(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const file = data.get("photo");
    setBusy(true);
    try {
      let photo: string | null = null;
      if (file instanceof File && file.size > 0) {
        photo = await shrinkPhoto(file);
      }
      await createProduct({
        data: {
          pin,
          name: String(data.get("name") ?? ""),
          price_inr: Number(data.get("price")),
          age_group: String(data.get("age") ?? ""),
          description: String(data.get("description") ?? ""),
          color: String(data.get("color") || "#D61F36"),
          photo,
        },
      });
      form.reset();
      toast.success("Car saved to the shop");
      await router.invalidate();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Could not save this car",
      );
    } finally {
      setBusy(false);
    }
  }

  async function onRemove(id: string) {
    try {
      await removeProduct({ data: { pin, id } });
      toast.success("Car removed");
      await router.invalidate();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Could not remove this car",
      );
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,22rem)_1fr]">
      <form
        onSubmit={onAdd}
        className="h-fit rounded-xl border-2 border-dashed border-primary/50 bg-card p-5"
      >
        <h2 className="font-display text-2xl font-semibold">Add a car</h2>
        <p className="mt-1 text-sm text-muted">
          Name, price, and an optional photo. Saved cars show up in the shop
          for every customer.
        </p>
        <div className="mt-4 grid gap-3">
          <Label>
            Car name
            <Input name="name" required maxLength={80} />
          </Label>
          <div className="grid grid-cols-2 gap-3">
            <Label>
              Price (₹)
              <Input name="price" type="number" min={1} required />
            </Label>
            <Label>
              Age group
              <Input name="age" placeholder="3–6 yrs" maxLength={40} />
            </Label>
          </div>
          <Label>
            Short description
            <Textarea name="description" rows={3} maxLength={240} />
          </Label>
          <Label>
            Accent color
            <Input name="color" type="color" defaultValue="#D61F36" />
          </Label>
          <Label>
            Photo
            <Input name="photo" type="file" accept="image/*" />
          </Label>
          <Button type="submit" disabled={busy}>
            {busy ? "Saving…" : "Save product"}
          </Button>
        </div>
      </form>

      <div>
        <h2 className="font-display text-2xl font-semibold">Your products</h2>
        {products.length === 0 ? (
          <p className="mt-3 text-muted">No products yet.</p>
        ) : (
          <ul className="mt-4 divide-y-2 divide-dashed divide-border">
            {products.map((product) => (
              <li
                key={product.id}
                className="flex items-center gap-3 py-3 first:pt-0"
              >
                {product.photo ? (
                  <img
                    src={product.photo}
                    alt=""
                    className="size-14 rounded-sm object-cover"
                  />
                ) : (
                  <span
                    className="size-14 rounded-sm"
                    style={{ background: product.color }}
                    aria-hidden="true"
                  />
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{product.name}</p>
                  <p className="text-sm text-muted tabular-nums">
                    {formatInr(product.price_inr)}
                    {product.age_group ? ` · ${product.age_group}` : ""}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onRemove(product.id)}
                >
                  Remove
                </Button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export function readStoredPin() {
  try {
    return sessionStorage.getItem(PIN_KEY);
  } catch {
    return null;
  }
}
