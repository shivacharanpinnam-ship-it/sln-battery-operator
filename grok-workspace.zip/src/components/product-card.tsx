import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCart, useShopUi } from "@/lib/cart";
import type { Product } from "@/lib/products";
import { formatInr } from "@/lib/utils";
import { toast } from "sonner";

export function ProductCard({ product }: { product: Product }) {
  const add = useCart((s) => s.add);
  const openCart = useShopUi((s) => s.openCart);

  function onAdd() {
    add(product.id);
    toast.success(`${product.name} added to cart`, {
      action: {
        label: "View cart",
        onClick: openCart,
      },
    });
  }

  return (
    <article
      className="flex flex-col overflow-hidden rounded-xl border-[2.5px] bg-card"
      style={{ borderColor: product.color }}
    >
      <div className="pic-frame relative overflow-hidden bg-sky/40">
        {product.photo ? (
          <img
            src={product.photo}
            alt={product.name}
            className="size-full object-cover"
          />
        ) : (
          <div
            className="flex size-full items-center justify-center"
            style={{ background: product.color }}
            aria-hidden="true"
          >
            <span className="font-display text-5xl text-primary-foreground">
              {product.name.slice(0, 1)}
            </span>
          </div>
        )}
        {product.age_group ? (
          <Badge className="absolute top-3 left-3">{product.age_group}</Badge>
        ) : null}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <h3 className="font-display text-xl font-semibold leading-tight">
          {product.name}
        </h3>
        <p className="flex-1 text-sm text-muted">{product.description}</p>
        <div className="mt-1 flex items-center justify-between gap-3">
          <p className="font-display text-2xl font-bold text-primary tabular-nums">
            {formatInr(product.price_inr)}
          </p>
          <Button onClick={onAdd}>Add to cart</Button>
        </div>
      </div>
    </article>
  );
}
