import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="border-t-8 border-primary px-5 py-8 text-center text-sm text-muted">
      <p>© {new Date().getFullYear()} Sln Electric Toys</p>
      <Link
        to="/owner"
        className="mt-2 inline-block font-semibold text-foreground/70 hover:text-primary"
      >
        Owner panel
      </Link>
    </footer>
  );
}
