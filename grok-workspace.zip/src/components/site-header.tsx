import { Link } from "@tanstack/react-router";
import { ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cartCount, useCart, useShopUi } from "@/lib/cart";

export function SiteHeader() {
  const items = useCart((s) => s.items);
  const openCart = useShopUi((s) => s.openCart);
  const count = cartCount(items);

  return (
    <header className="sticky top-0 z-40 border-b-2 border-border bg-background/95 pt-[env(safe-area-inset-top)] backdrop-blur-sm">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
        <Link
          to="/"
          className="font-display mr-auto text-lg font-bold leading-none sm:text-xl"
        >
          <span className="text-primary">Sln</span>{" "}
          <span className="text-ring">Electric</span>{" "}
          <span className="text-hill">Toys</span>
        </Link>
        <nav className="hidden items-center gap-5 font-display text-sm font-semibold sm:flex">
          <a href="#shop" className="hover:text-primary">
            Shop
          </a>
          <a href="#contact" className="hover:text-primary">
            Contact
          </a>
        </nav>
        <Button onClick={openCart} aria-label={`Cart, ${count} items`}>
          <ShoppingBag className="size-4" />
          Cart
          <span className="tabular-nums">({count})</span>
        </Button>
      </div>
    </header>
  );
}
