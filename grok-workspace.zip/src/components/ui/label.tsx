import * as React from "react";
import { cn } from "@/lib/utils";

function Label({ className, ...props }: React.ComponentProps<"label">) {
  return (
    <label
      data-slot="label"
      className={cn(
        "text-sm font-semibold text-foreground [&_input]:mt-1.5 [&_textarea]:mt-1.5",
        className,
      )}
      {...props}
    />
  );
}

export { Label };
