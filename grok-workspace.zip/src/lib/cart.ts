import { create } from "zustand";
import { persist } from "zustand/middleware";

export type CartItem = { id: string; qty: number };

type CartState = {
  items: CartItem[];
  add: (id: string) => void;
  inc: (id: string) => void;
  dec: (id: string) => void;
  remove: (id: string) => void;
  clear: () => void;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      add: (id) => {
        const current = get().items.find((item) => item.id === id);
        if (current) {
          set({
            items: get().items.map((item) =>
              item.id === id ? { ...item, qty: item.qty + 1 } : item,
            ),
          });
          return;
        }
        set({ items: [...get().items, { id, qty: 1 }] });
      },
      inc: (id) =>
        set({
          items: get().items.map((item) =>
            item.id === id ? { ...item, qty: item.qty + 1 } : item,
          ),
        }),
      dec: (id) =>
        set({
          items: get()
            .items.map((item) =>
              item.id === id ? { ...item, qty: item.qty - 1 } : item,
            )
            .filter((item) => item.qty > 0),
        }),
      remove: (id) =>
        set({ items: get().items.filter((item) => item.id !== id) }),
      clear: () => set({ items: [] }),
    }),
    { name: "sln-cart", skipHydration: true },
  ),
);

export function cartCount(items: CartItem[]) {
  return items.reduce((sum, item) => sum + item.qty, 0);
}

type ShopUiState = {
  cartOpen: boolean;
  checkoutOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  openCheckout: () => void;
  closeCheckout: () => void;
};

export const useShopUi = create<ShopUiState>((set) => ({
  cartOpen: false,
  checkoutOpen: false,
  openCart: () => set({ cartOpen: true, checkoutOpen: false }),
  closeCart: () => set({ cartOpen: false }),
  openCheckout: () => set({ cartOpen: false, checkoutOpen: true }),
  closeCheckout: () => set({ checkoutOpen: false }),
}));
