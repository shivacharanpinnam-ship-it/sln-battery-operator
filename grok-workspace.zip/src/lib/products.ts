import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export type Product = {
  id: string;
  name: string;
  price_inr: number;
  age_group: string;
  description: string;
  color: string;
  photo: string | null;
  created_at: string;
};

const pinSchema = z.string().trim().min(4).max(32);

const productInput = z.object({
  pin: pinSchema,
  name: z.string().trim().min(1).max(80),
  price_inr: z.number().int().min(1).max(10_000_000),
  age_group: z.string().trim().max(40),
  description: z.string().trim().max(240),
  color: z
    .string()
    .regex(/^#[0-9A-Fa-f]{6}$/)
    .optional(),
  photo: z.string().max(250_000).nullable(),
});

async function assertOwnerPin(pin: string) {
  const { createHash, timingSafeEqual } = await import("node:crypto");
  const { getSql } = await import("@/lib/db");
  const hash = createHash("sha256")
    .update(`sln-toys:${pin.trim()}`)
    .digest("hex");
  const sql = await getSql();
  const rows = await sql<{ pin_hash: string }>`
    select pin_hash from shop_settings where id = 1
  `;
  const expected = rows[0]?.pin_hash ?? "";
  const left = Buffer.from(hash);
  const right = Buffer.from(expected);
  if (left.length !== right.length || !timingSafeEqual(left, right)) {
    throw new Error("Wrong PIN. Use the last 5 digits of the shop phone.");
  }
}

export const listProducts = createServerFn({ method: "GET" }).handler(
  async () => {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    return sql<Product>`
      select
        id,
        name,
        price_inr,
        age_group,
        description,
        color,
        photo,
        created_at::text as created_at
      from products
      order by created_at desc
    `;
  },
);

export const verifyOwnerPin = createServerFn({ method: "POST" })
  .validator(z.object({ pin: pinSchema }))
  .handler(async ({ data }) => {
    await assertOwnerPin(data.pin);
    return { ok: true as const };
  });

export const createProduct = createServerFn({ method: "POST" })
  .validator(productInput)
  .handler(async ({ data }) => {
    await assertOwnerPin(data.pin);
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const id = `p-${Date.now().toString(36)}`;
    await sql`
      insert into products (id, name, price_inr, age_group, description, color, photo)
      values (
        ${id},
        ${data.name},
        ${data.price_inr},
        ${data.age_group},
        ${data.description},
        ${data.color ?? "#D61F36"},
        ${data.photo}
      )
    `;
    return { id };
  });

export const removeProduct = createServerFn({ method: "POST" })
  .validator(z.object({ pin: pinSchema, id: z.string().min(1).max(80) }))
  .handler(async ({ data }) => {
    await assertOwnerPin(data.pin);
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    await sql`delete from products where id = ${data.id}`;
    return { ok: true as const };
  });
