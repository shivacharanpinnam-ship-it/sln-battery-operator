export const SHOP = {
  name: "Sln Electric Toys",
  phone: "+91 99896 48742",
  phone2: "+91 76610 98439",
  wa: "919989648742",
  email: "pinnamraghavendra589@gmail.com",
  addresses: [
    "11th Floor, 4-97, near Gem Motors, beside More Super Market, Kondapur, Raghavendra Colony",
    "Sai Chandra Colony, Plot No 85, Narsingi – Puppalaguda Main Rd, opposite GREENSPACE PRIME",
  ],
} as const;

export type CheckoutDetails = {
  name: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  pincode: string;
  state: string;
};

export type OrderLine = {
  name: string;
  qty: number;
  price: number;
};

export function buildOrderMessage(
  orderId: string,
  lines: OrderLine[],
  total: number,
  details: CheckoutDetails,
) {
  const items = lines
    .map(
      (line) =>
        `${line.name} × ${line.qty} = ₹${line.price * line.qty}`,
    )
    .join("\n");
  return [
    `New order ${orderId} from ${SHOP.name}`,
    items,
    `Total: ₹${total}`,
    "",
    `Name: ${details.name}`,
    `Phone: ${details.phone}`,
    details.email ? `Email: ${details.email}` : "",
    `Delivery address: ${details.address}, ${details.city}, ${details.state} - ${details.pincode}`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function whatsappOrderUrl(message: string) {
  return `https://wa.me/${SHOP.wa}?text=${encodeURIComponent(message)}`;
}

export function telHref(phone: string) {
  return `tel:${phone.replace(/\s/g, "")}`;
}

export function mapsHref(address: string) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
}
