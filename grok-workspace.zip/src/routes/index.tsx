import { createFileRoute } from "@tanstack/react-router";
import { CartDialog } from "@/components/cart-dialog";
import { CheckoutDialog } from "@/components/checkout-dialog";
import { ContactSection } from "@/components/contact-section";
import { Hero } from "@/components/hero";
import { ProductGrid } from "@/components/product-grid";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { listProducts } from "@/lib/products";

export const Route = createFileRoute("/")({
  loader: () => listProducts(),
  component: Home,
});

function Home() {
  const products = Route.useLoaderData();

  return (
    <div className="min-h-dvh">
      <SiteHeader />
      <Hero />
      <section id="shop" className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <h2 className="font-display text-[clamp(1.8rem,4vw,2.6rem)] font-semibold">
          Our battery cars
        </h2>
        <p className="mt-2 mb-8 text-muted">
          Tap Add to cart on the cars you like. Checkout sends your delivery
          address to the shop on WhatsApp.
        </p>
        <ProductGrid products={products} />
      </section>
      <ContactSection />
      <SiteFooter />
      <CartDialog products={products} />
      <CheckoutDialog products={products} />
    </div>
  );
}
