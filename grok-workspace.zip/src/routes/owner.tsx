import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { OwnerCatalog, OwnerUnlock, readStoredPin } from "@/components/owner-form";
import { listProducts } from "@/lib/products";

export const Route = createFileRoute("/owner")({
  loader: () => listProducts(),
  component: OwnerPage,
});

function OwnerPage() {
  const products = Route.useLoaderData();
  const [pin, setPin] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setPin(readStoredPin());
    setReady(true);
  }, []);

  return (
    <main className="mx-auto min-h-dvh max-w-6xl px-5 py-10 sm:px-8">
      <Link
        to="/"
        className="mb-6 inline-flex items-center gap-2 font-display text-sm font-semibold text-muted hover:text-foreground"
      >
        <ArrowLeft className="size-4" />
        Back to shop
      </Link>
      { !ready ? (
        <p className="text-muted">Loading owner panel…</p>
      ) : pin ? (
        <>
          <h1 className="font-display mb-6 text-4xl font-semibold">
            Owner panel
          </h1>
          <OwnerCatalog pin={pin} products={products} />
        </>
      ) : (
        <OwnerUnlock onUnlock={setPin} />
      )}
    </main>
  );
}
